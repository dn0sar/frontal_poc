/* This file is auto generated, version 49~16.04.112+fixandnotpr2 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#49~16.04.112+fixandnotpr2 SMP Fri Sep 18 22:41:59 CEST 2020"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "tildem"
#define LINUX_COMPILER "gcc version 6.3.0 20170519 (Ubuntu/Linaro 6.3.0-18ubuntu2~16.04)"
